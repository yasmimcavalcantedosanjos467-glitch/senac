console.log("JS funcionando");

const form = document.getElementById("form");
const nomeInput = document.getElementById("nome");
const idadeInput = document.getElementById("idade");
const resultado = document.getElementById("resultado");
const lista = document.getElementById("lista");
const limparBtn = document.getElementById("limpar");

form.addEventListener("submit", function(event) {
  event.preventDefault(); // NÃO RECARREGA

  const nome = nomeInput.value.trim();
  const idade = Number(idadeInput.value);

  if (nome === "" || idadeInput.value === "") {
    resultado.textContent = "Preencha todos os campos!";
    resultado.className = "erro";
    return;
  }

  if (idade < 0 || idade > 120) {
    resultado.textContent = "Idade inválida!";
    resultado.className = "erro";
    return;
  }

  let tipo = "";
  let classe = "";

  if (idade < 18) {
    tipo = "Menor de idade";
    classe = "menor";
  } else {
    tipo = "Maior de idade";
    classe = "maior";
  }

  resultado.textContent = `${nome} (${idade}) - ${tipo}`;
  resultado.className = classe;

  const li = document.createElement("li");
  li.textContent = `${nome} - ${idade} anos (${tipo})`;
  li.className = classe;

  lista.appendChild(li);

  nomeInput.value = "";
  idadeInput.value = "";
});

limparBtn.addEventListener("click", function() {
  lista.innerHTML = "";
  resultado.textContent = "";
  resultado.className = "";
});